import java.util.ArrayList;

public interface Bracket {
	public ArrayList<String> getPrintThis();
	public ArrayList<game> getGames();
	public void advanceSchedule();
}
